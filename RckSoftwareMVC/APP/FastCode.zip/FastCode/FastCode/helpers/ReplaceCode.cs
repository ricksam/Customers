﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastCode.helpers
{
    public class ReplaceCode
    {
        //public static string[] DefaultTFToEntity = new string[] { "namespace", "entity", "entity.index", "entity.size", "entity.count", "field", "field.index", "field.size", "field.count", "pk" };
        //public static string[] DefaultTFToEntity = new string[] { "namespace", "entity", "entity.index", "entity.size", "entity.count", "field", "field.index", "field.size", "field.count", "pk" };

        private static string GetExistingitem(string line, string[] fields)
        {
            foreach (var item in fields)
            {
                string search = "[" + item + "]";
                if (line.Contains(search))
                {
                    //Log.Text(search, ConsoleColor.Yellow);
                    return search;
                }
            }

            return "";
        }

        private static bool HasField(string line, string[] fields)
        {
            return !string.IsNullOrEmpty(GetExistingitem(line, fields));
        }

        public static string ByEntity(Entity entity, ProjectScheme project, string line)
        {
            string[] SearchFields = new string[] { "namespace", "entity", "entity.index", "entity.count", "pk" };
            while (HasField(line, SearchFields))
            {
                //,  "field", "field.index", "field.size", "field.count", "pk"
                string existing = GetExistingitem(line, SearchFields);
                if (existing == "[namespace]")
                {
                    line = line.Replace("[namespace]", project.name);
                }
                else if (existing == "[entity]")
                {
                    line = line.Replace("[entity]", entity.name);
                }
                else if (existing == "[entity.index]")
                {
                    line = line.Replace("[entity.index]", project.entities.IndexOf(entity).ToString());
                }
                else if (existing == "[entity.count]")
                {
                    line = line.Replace("[entity.count]", project.entities.Count.ToString());
                }
                else if (existing == "[pk]")
                {
                    line = line.Replace("[pk]", entity.fields.FirstOrDefault(q => q.type == "pk")?.name);
                }
            }
            return line;
        }

        private static string ReplaceByType(TemplateField t_field, string new_line, bool isFirst, bool isLast, string text_replace)
        {
            if ((isFirst && !t_field.role.first) || (isLast && !t_field.role.first) || (!isFirst && !isLast && !t_field.role.outhers))
            {
                return new_line.Replace("["+t_field.name+"]", "");
            }
            return new_line.Replace("[" + t_field.name + "]", text_replace);
        }

        public static string ByFieldList(Template template, Entity entity, ProjectScheme project, string line)
        {
            line = ByEntity(entity, project, line);
            string[] SearchFields = new string[] { "field", "field.size", "field.role", "field.placeholder", "field.index", "field.count" };
            string new_lines = "";
            var fields = entity.fields.Where(q => q.type != "pk").ToList();
            for (int i = 0; i < fields.Count; i++)
            {
                EntityField field = fields[i];
                bool FieldIsFirst = i == 0;
                bool FieldIsLast = i == entity.fields.Count - 1;

                string new_line = line;
                while (HasField(new_line, SearchFields))
                {
                    string existing = GetExistingitem(new_line, SearchFields);
                    if (existing == "[field]")
                    {
                        new_line = new_line.Replace("[field]", field.name);
                    }
                    else if (existing == "[field.title]")
                    {
                        new_line = new_line.Replace("[field.title]", field.title);
                    }
                    else if (existing == "[field.size]")
                    {
                        new_line = new_line.Replace("[field.index]", field.size);
                    }
                    else if (existing == "[field.role]")
                    {
                        new_line = new_line.Replace("[field.role]", field.role);
                    }
                    else if (existing == "[field.placeholder]")
                    {
                        new_line = new_line.Replace("[field.placeholder]", field.placeholder);
                    }
                    else if (existing == "[field.index]")
                    {
                        new_line = new_line.Replace("[field.index]", entity.fields.IndexOf(field).ToString());
                    }
                    else if (existing == "[field.index]")
                    {
                        new_line = new_line.Replace("[field.index]", entity.fields.Count.ToString());
                    }


                }

                string[] template_fields = template.fields.Select(q => q.name).ToArray();
                while (HasField( new_line, template_fields))
                {
                    string existing = GetExistingitem( new_line, template_fields);
                    foreach (var t_field in template.fields)
                    {
                        if (existing == "[" + t_field.name + "]")
                        {
                            if (field.type == "number")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.number);
                            }
                            else if (field.type == "value")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.value);
                            }
                            else if (field.type == "text")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.text);
                            }
                            else if (field.type == "bool")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.@bool);
                            }
                            else if (field.type == "date")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.date);
                            }
                            else if (field.type == "time")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.time);
                            }
                            else if (field.type == "file")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.file);
                            }
                            else if (field.type == "password")
                            {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.password);
                            }
                            else if (project.entities.FirstOrDefault(q=>q.name == field.type)!=null) {
                                new_line = ReplaceByType(t_field, new_line, FieldIsFirst, FieldIsLast, t_field.type.fk);
                            }
                        }


                    }

                }


                new_lines += new_line + "\n";
            }

            return new_lines;
        }

        public static string ByentityList(Template template, ProjectScheme project, string line)
        {
            string[] SearchFields = new string[] { "namespace", "entity", "entity.index", "entity.count", "pk" };
            string new_lines = "";

            foreach (var entity in project.entities)
            {
                string new_line = line;
                while (HasField( new_line, SearchFields))
                {
                    string existing = GetExistingitem( new_line, SearchFields);
                    if (existing == "[namespace]")
                    {
                        new_line = new_line.Replace("[namespace]", project.name);
                    }
                    else if (existing == "[entity]")
                    {
                        new_line = new_line.Replace("[entity]", entity.name);
                    }
                    else if (existing == "[entity.index]")
                    {
                        new_line = new_line.Replace("[entity.index]", project.entities.IndexOf(entity).ToString());
                    }
                    else if (existing == "[entity.count]")
                    {
                        new_line = new_line.Replace("[entity.count]", project.entities.Count.ToString());
                    }
                    else if (existing == "[pk]")
                    {
                        new_line = new_line.Replace("[pk]", entity.fields.FirstOrDefault(q => q.type == "pk")?.name);
                    }
                }
                new_lines += new_line + "\n";
            }

            return new_lines;
        }
    }
}
