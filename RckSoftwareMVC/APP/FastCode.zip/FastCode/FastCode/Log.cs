﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastCode
{
    public class Log
    {
        public static void DefaultColor() {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Title(string text, ConsoleColor color = ConsoleColor.Gray) {
            DefaultColor();
            Console.BackgroundColor = color;
            Console.WriteLine(" "+text+" ");
            DefaultColor();

        }
        public static void Text(string text, ConsoleColor color = ConsoleColor.Gray)
        {
            DefaultColor();
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            DefaultColor();
        }

        public static void Error(string text) {
            Title(text, ConsoleColor.Red);
        }
    }
}
